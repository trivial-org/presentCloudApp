export declare class Test {
    mean(): string;
}