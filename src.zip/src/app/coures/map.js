"use strict";
exports.__esModule = true;
var Test = (function () {
    function Test() {
        // var baidumap_location = require('../../../plugins/cordova-plugin-baidumaplocation/www/baidumap_location.js');
        // alert(1)
  
      
    }  function initBaiduMap() {
            // 进行定位
            // if ('baidumap_location' in window) {
            //     alert(3)
            //     baidumap_location.getCurrentPosition(function (result) {
            //         console.log(result);
            //     }, function (error) {
            //         console.error(error);
            //     });
            // } else {
            //     alert(4)
            //     console.error('baidumap_location is undefined');
            // }
        } 
    Test.prototype.mean = async function () {

//         for(let l in navigator.geolocation) {
//             navigator.geolocation.getCurrentPosition(function(position){alert(1)})
//         }
//         let gps = ''
//   if(navigator.geolocation)
// {
//     alert('开始')
//    await navigator.geolocation.getCurrentPosition(function(position){
//         // 获取成功
//         alert(1111111111111111)
//         alert(position)
//         gps = position
//     }, function(err){
//         alert(222222222222222, err)
//         // 获取失败
//     });
// }
// else
// {
//   alert(1)
//     console.debug('不支持获取GPS地理位置');
// }
// alert(gps)
      
        // baidumap_location.getCurrentPosition(function (result) {
        //     var latitude=result.latitude;
        //     var lontitude=result.lontitude;
        //     alert(latitude+"==="+lontitude)
        //     }, function (error) {
        //     alert(error)
        //     });
        // return "this is a test string！";
    };
    return Test;
}());
exports.Test = Test;