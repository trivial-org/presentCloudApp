import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userag',
  templateUrl: './userag.page.html',
  styleUrls: ['./userag.page.scss'],
})
export class UseragPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
