import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coursemsg',
  templateUrl: './coursemsg.component.html',
  styleUrls: ['./coursemsg.component.scss'],
})
export class CoursemsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
