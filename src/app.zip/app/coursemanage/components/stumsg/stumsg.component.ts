import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stumsg',
  templateUrl: './stumsg.component.html',
  styleUrls: ['./stumsg.component.scss'],
})
export class StumsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
