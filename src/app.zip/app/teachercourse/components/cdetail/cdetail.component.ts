import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cdetail',
  templateUrl: './cdetail.component.html',
  styleUrls: ['./cdetail.component.scss'],
})
export class CdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
