import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TeachercoursePageRoutingModule } from './teachercourse-routing.module';

import { TeachercoursePage } from './teachercourse.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TeachercoursePageRoutingModule
  ],
  declarations: [TeachercoursePage]
})
export class TeachercoursePageModule {}
