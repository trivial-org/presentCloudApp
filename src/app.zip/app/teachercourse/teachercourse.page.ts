import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teachercourse',
  templateUrl: './teachercourse.page.html',
  styleUrls: ['./teachercourse.page.scss'],
})
export class TeachercoursePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
